from miniish.sketch import *

def check(args, out):
    SKETCH.language.compile(args, out, checkonly=True)
