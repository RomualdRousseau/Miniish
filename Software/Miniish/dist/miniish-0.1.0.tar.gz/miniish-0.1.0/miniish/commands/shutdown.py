from pyco import sys

def shutdown_(args, out):
    out.print("bye")
    sys.shutdown()