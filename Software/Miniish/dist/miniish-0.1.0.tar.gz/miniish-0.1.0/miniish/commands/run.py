from miniish.sketch import _run

def run_(args, out):
    _run(args, out)